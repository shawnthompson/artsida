<!DOCTYPE html>
<html>
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<title>Artsida</title>
	<link href="style.css" rel="stylesheet" />
	<meta content="index, follow" name="robots" />
</head>
<body>
<div class="wrap">
<img src="ARTSIDA5logo.jpg">
<h2><strong>Artsida.org</strong></h2>
<p>est actuellement en préparation pour la prochaine édition.</p>
<a href="http://accmontreal.org/fr/"><img src="Website-Logo-FR-300x50.jpg" alt="Sida bénévoles Montréal"></strong></a>


<p>Nous vous remercions de votre compr&eacute;hension.</p>
<br/><br/><br/>

<h2><strong>Artsida.org</strong></h2>
<p>is now in the process of an overhaul for the next edition.</p>
<a href="http://accmontreal.org"><img src="ACCM-Logo-Small-300x54.jpg" alt="AIDS Community Care Montreal"></a>


<p>Thanks for you comprehension.</p>
</div>
</body>
</html>